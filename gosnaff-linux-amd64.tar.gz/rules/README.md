# SnaffRules

Copied from [Snaffler](https://github.com/SnaffCon/Snaffler) and modified to work with this code instead
